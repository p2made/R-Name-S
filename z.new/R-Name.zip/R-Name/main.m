//
//  main.m
//  Active R-Name
//
//  Created by Yoichi Tagaya on Tue Nov 05 2002.
//  Copyright (c) 2002 Yoichi Tagaya. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char *argv[])
{
    return NSApplicationMain(argc, argv);
}
